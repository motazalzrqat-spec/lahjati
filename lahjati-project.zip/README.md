# لهجتي (Lahjati) 🗣️

> تطبيق Next.js لتعلم اللهجات العربية بالذكاء الاصطناعي

## الميزات

- 🤖 **محادثات Claude AI** — تعلم اللهجات مع AI يفهم السياق العربي
- 📚 **٦ دروس تعليمية** — من المبتدئ للمتقدم مع نطق
- 📖 **قاموس ٢٠+ كلمة** — مع فلاتر وبحث متقدم
- 👤 **ملف شخصي** — إنجازات، نقاط XP، تتبع التقدم
- 🌍 **٦ لهجات** — مصري، سعودي، خليجي، شامي، مغربي، عراقي

## التشغيل المحلي

```bash
# 1. تثبيت المتطلبات
npm install

# 2. إنشاء ملف البيئة
cp .env.local.example .env.local

# 3. أضف مفتاح Anthropic API في .env.local
# ANTHROPIC_API_KEY=sk-ant-...

# 4. تشغيل المشروع
npm run dev
```

افتح [http://localhost:3000](http://localhost:3000)

## الحصول على مفتاح API

1. اذهب إلى [console.anthropic.com](https://console.anthropic.com)
2. أنشئ حساباً أو سجل دخولاً
3. انتقل إلى API Keys وأنشئ مفتاحاً جديداً
4. أضفه في `.env.local`

## النشر على Vercel

```bash
# تثبيت Vercel CLI
npm i -g vercel

# النشر
vercel

# أضف متغير البيئة في لوحة Vercel:
# ANTHROPIC_API_KEY = مفتاحك
```

أو اضغط على الزر:

[![Deploy with Vercel](https://vercel.com/button)](https://vercel.com/new)

## هيكل المشروع

```
lahjati/
├── app/
│   ├── page.tsx          # الصفحة الرئيسية
│   ├── chat/page.tsx     # صفحة المحادثة
│   ├── lessons/page.tsx  # الدروس
│   ├── dictionary/page.tsx # القاموس
│   ├── profile/page.tsx  # الملف الشخصي
│   ├── api/chat/route.ts # Claude API endpoint
│   └── globals.css
├── components/
│   └── Navbar.tsx
├── lib/
│   └── data.ts           # البيانات المشتركة
└── vercel.json
```

## المتطلبات التقنية

- Node.js 18+
- Next.js 15
- `@anthropic-ai/sdk`
- Tailwind CSS v4
