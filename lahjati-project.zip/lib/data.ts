export const dialects = [
  {
    id: "egyptian",
    name: "مصري",
    nameEn: "Egyptian",
    flag: "🇪🇬",
    color: "from-blue-500 to-purple-600",
    accent: "#3b82f6",
    example: "عامل إيه يا صاحبي؟",
    description: "أكثر اللهجات انتشاراً في العالم العربي",
    speakers: "١٠٠+ مليون",
    region: "مصر",
    systemPrompt: `أنت مدرس لهجة مصرية متخصص. تحدث وعلّم باللهجة المصرية الدارجة. 
استخدم كلمات مصرية أصيلة مثل: عامل إيه، يا صاحبي، تمام، أيوه، لأ، مش كده، إزيك، براحة، جامد، زي الفل.
عند تصحيح جمل المستخدم، اشرح الفرق بين الفصحى والمصرية. كن ودوداً ومشجعاً.`
  },
  {
    id: "saudi",
    name: "سعودي",
    nameEn: "Saudi",
    flag: "🇸🇦",
    color: "from-green-500 to-emerald-600",
    accent: "#10b981",
    example: "وشلونك يا بعدي؟",
    description: "لهجة الجزيرة العربية الأصيلة",
    speakers: "٣٥+ مليون",
    region: "المملكة العربية السعودية",
    systemPrompt: `أنت مدرس لهجة سعودية متخصص. تحدث وعلّم باللهجة السعودية الخليجية.
استخدم كلمات سعودية أصيلة مثل: شلونك، وش السالفة، زين، ما شاء الله، يا هلا، عاد، تعال، بعدي، صحيح.
اشرح الفروق بين مناطق المملكة المختلفة (نجد، الحجاز، الجنوب). كن ودوداً ومرحباً.`
  },
  {
    id: "gulf",
    name: "خليجي",
    nameEn: "Gulf",
    flag: "🌴",
    color: "from-amber-500 to-orange-600",
    accent: "#f59e0b",
    example: "هلا والله فيك",
    description: "لهجة دول الخليج العربي",
    speakers: "٢٠+ مليون",
    region: "الإمارات، الكويت، قطر، البحرين",
    systemPrompt: `أنت مدرس لهجة خليجية متخصص. تحدث وعلّم باللهجة الخليجية الإماراتية والكويتية.
استخدم كلمات خليجية أصيلة مثل: هلا والله، كيفك، شو أخبارك، ماكو مشكلة، خوش، يبه، وايد، بعدين، شوفي.
اشرح الفروق بين اللهجات الخليجية المختلفة. كن كريماً ومضيافاً في أسلوبك.`
  },
  {
    id: "levantine",
    name: "شامي",
    nameEn: "Levantine",
    flag: "🇸🇾",
    color: "from-red-500 to-rose-600",
    accent: "#ef4444",
    example: "كيفك؟ شو أخبارك؟",
    description: "لهجة بلاد الشام العريقة",
    speakers: "٣٥+ مليون",
    region: "سوريا، لبنان، الأردن، فلسطين",
    systemPrompt: `أنت مدرس لهجة شامية متخصص. تحدث وعلّم باللهجة الشامية السورية اللبنانية.
استخدم كلمات شامية أصيلة مثل: كيفك، شو، هيك، منيح، عنجد، يلا، معلش، بكرا، هلق، تعبانة، مبسوط.
اشرح الفروق بين اللهجات الشامية المختلفة. كن دافئاً وعائلياً في أسلوبك.`
  },
  {
    id: "moroccan",
    name: "مغربي",
    nameEn: "Moroccan",
    flag: "🇲🇦",
    color: "from-indigo-500 to-blue-600",
    accent: "#6366f1",
    example: "لباس عليك؟",
    description: "الدارجة المغربية الغنية",
    speakers: "٣٦+ مليون",
    region: "المغرب، الجزائر، تونس",
    systemPrompt: `أنت مدرس لهجة مغربية متخصص. تحدث وعلّم باللهجة المغربية الدارجة.
استخدم كلمات مغربية أصيلة مثل: لباس، واخا، بزاف، دابا، كيداير، مزيان، بغيت، أنا غادي، سير، خويا.
اشرح تأثير الأمازيغية والفرنسية على الدارجة. كن متحمساً وفخوراً بالهوية المغربية.`
  },
  {
    id: "iraqi",
    name: "عراقي",
    nameEn: "Iraqi",
    flag: "🇮🇶",
    color: "from-teal-500 to-cyan-600",
    accent: "#06b6d4",
    example: "شلونك عيني؟",
    description: "لهجة بلاد الرافدين",
    speakers: "٤٠+ مليون",
    region: "العراق",
    systemPrompt: `أنت مدرس لهجة عراقية متخصص. تحدث وعلّم باللهجة العراقية الدارجة.
استخدم كلمات عراقية أصيلة مثل: شلونك، عيني، گلبي، پارتي، زين، ماكو، موجود، چاي، چلو، مرحبا أهلاً.
اشرح الفروق بين لهجة بغداد والجنوب والموصل. كن حاراً وكريماً في أسلوبك.`
  },
];

export const lessonsData = [
  {
    id: 1,
    title: "التحية والترحيب",
    titleEn: "Greetings",
    icon: "👋",
    level: "مبتدئ",
    duration: "١٥ دقيقة",
    xp: 100,
    dialects: ["egyptian", "saudi", "levantine"],
    phrases: {
      egyptian: [
        { arabic: "إزيك؟", meaning: "كيف حالك؟", pronunciation: "izzayak?" },
        { arabic: "تمام الحمد لله", meaning: "بخير والحمد لله", pronunciation: "tamam el-hamdu lillah" },
        { arabic: "أهلاً وسهلاً", meaning: "مرحباً بك", pronunciation: "ahlan wa sahlan" },
      ],
      saudi: [
        { arabic: "كيف حالك؟", meaning: "كيف حالك؟", pronunciation: "kayf halak?" },
        { arabic: "بخير والحمد لله", meaning: "بخير", pronunciation: "bikhair walhamdulillah" },
        { arabic: "هلا والله", meaning: "أهلاً بك", pronunciation: "hala wallah" },
      ],
      levantine: [
        { arabic: "كيفك؟", meaning: "كيف حالك؟", pronunciation: "kifak?" },
        { arabic: "منيح شكراً", meaning: "بخير شكراً", pronunciation: "mnih shukran" },
        { arabic: "أهلاً فيك", meaning: "أهلاً بك", pronunciation: "ahlan fik" },
      ],
    }
  },
  {
    id: 2,
    title: "في المطعم",
    titleEn: "At the Restaurant",
    icon: "🍽️",
    level: "مبتدئ",
    duration: "٢٠ دقيقة",
    xp: 150,
    dialects: ["egyptian", "gulf", "moroccan"],
    phrases: {
      egyptian: [
        { arabic: "عايز الأكل", meaning: "أريد الطعام", pronunciation: "aayiz el-akl" },
        { arabic: "الحساب لو سمحت", meaning: "الفاتورة من فضلك", pronunciation: "el-hisab law samaht" },
        { arabic: "الأكل كان تحفة", meaning: "الطعام كان رائعاً", pronunciation: "el-akl kan tuhfa" },
      ],
      gulf: [
        { arabic: "أبي آكل", meaning: "أريد أن آكل", pronunciation: "abi aakul" },
        { arabic: "الحساب عطني", meaning: "أعطني الفاتورة", pronunciation: "al-hisab atni" },
        { arabic: "الأكل زين", meaning: "الطعام لذيذ", pronunciation: "el-akl zain" },
      ],
      moroccan: [
        { arabic: "بغيت ناكل", meaning: "أريد أن آكل", pronunciation: "bghit nakul" },
        { arabic: "الحساب عافاك", meaning: "الفاتورة من فضلك", pronunciation: "al-hisab afak" },
        { arabic: "الماكلة مزيانة", meaning: "الطعام لذيذ", pronunciation: "el-makla mzyana" },
      ],
    }
  },
  {
    id: 3,
    title: "التسوق والأسواق",
    titleEn: "Shopping",
    icon: "🛍️",
    level: "متوسط",
    duration: "٢٥ دقيقة",
    xp: 200,
    dialects: ["egyptian", "iraqi", "moroccan"],
    phrases: {
      egyptian: [
        { arabic: "بكام ده؟", meaning: "بكم هذا؟", pronunciation: "bikam da?" },
        { arabic: "غالي أوي", meaning: "غالي جداً", pronunciation: "ghali awi" },
        { arabic: "خلينا نتفاهم", meaning: "دعنا نتفاهم", pronunciation: "khalina netfahem" },
      ],
      iraqi: [
        { arabic: "بچم هاذا؟", meaning: "بكم هذا؟", pronunciation: "bicham hadha?" },
        { arabic: "غالي كلش", meaning: "غالي جداً", pronunciation: "ghali kulish" },
        { arabic: "نتفاهم", meaning: "دعنا نتفاهم", pronunciation: "netfahem" },
      ],
      moroccan: [
        { arabic: "بشحال هاد؟", meaning: "بكم هذا؟", pronunciation: "bshhal had?" },
        { arabic: "غالي بزاف", meaning: "غالي جداً", pronunciation: "ghali bzaf" },
        { arabic: "خليني نتفاهمو", meaning: "دعنا نتفاهم", pronunciation: "khalini netfahmu" },
      ],
    }
  },
  {
    id: 4,
    title: "المواصلات",
    titleEn: "Transportation",
    icon: "🚕",
    level: "متوسط",
    duration: "٢٠ دقيقة",
    xp: 175,
    dialects: ["egyptian", "saudi", "levantine"],
    phrases: {
      egyptian: [
        { arabic: "فين المحطة؟", meaning: "أين المحطة؟", pronunciation: "fein el-mahatta?" },
        { arabic: "وقفني هنا", meaning: "أوقفني هنا", pronunciation: "wa'afni hena" },
        { arabic: "روح فين؟", meaning: "إلى أين تذهب؟", pronunciation: "ruh fein?" },
      ],
      saudi: [
        { arabic: "وين المحطة؟", meaning: "أين المحطة؟", pronunciation: "wain el-mahatta?" },
        { arabic: "وقفني هنا", meaning: "أوقفني هنا", pronunciation: "wa'afni hena" },
        { arabic: "وين رايح؟", meaning: "إلى أين تذهب؟", pronunciation: "wain rayih?" },
      ],
      levantine: [
        { arabic: "وين المحطة؟", meaning: "أين المحطة؟", pronunciation: "wain el-mahatta?" },
        { arabic: "وقفني هون", meaning: "أوقفني هنا", pronunciation: "wa'afni hon" },
        { arabic: "رايح على وين؟", meaning: "إلى أين تذهب؟", pronunciation: "rayih ala wain?" },
      ],
    }
  },
  {
    id: 5,
    title: "المشاعر والأحاسيس",
    titleEn: "Emotions",
    icon: "❤️",
    level: "متقدم",
    duration: "٣٠ دقيقة",
    xp: 250,
    dialects: ["egyptian", "gulf", "moroccan"],
    phrases: {
      egyptian: [
        { arabic: "أنا بحبك أوي", meaning: "أنا أحبك جداً", pronunciation: "ana bahibbak awi" },
        { arabic: "زعلان منك", meaning: "أنا غاضب منك", pronunciation: "zaalan minnak" },
        { arabic: "مبسوط جداً", meaning: "سعيد جداً", pronunciation: "mabsut giddan" },
      ],
      gulf: [
        { arabic: "أنا أحبك وايد", meaning: "أنا أحبك كثيراً", pronunciation: "ana uhibbak waied" },
        { arabic: "زعلان منك", meaning: "أنا غاضب منك", pronunciation: "zaalan minnak" },
        { arabic: "فرحان وايد", meaning: "سعيد جداً", pronunciation: "farhan waied" },
      ],
      moroccan: [
        { arabic: "كنبغيك بزاف", meaning: "أنا أحبك كثيراً", pronunciation: "knbghik bzaf" },
        { arabic: "معصب عليك", meaning: "أنا غاضب منك", pronunciation: "m3assab 3lik" },
        { arabic: "فرحان بزاف", meaning: "سعيد جداً", pronunciation: "farhan bzaf" },
      ],
    }
  },
  {
    id: 6,
    title: "العمل والأعمال",
    titleEn: "Work & Business",
    icon: "💼",
    level: "متقدم",
    duration: "٣٥ دقيقة",
    xp: 300,
    dialects: ["egyptian", "saudi", "levantine"],
    phrases: {
      egyptian: [
        { arabic: "الشغل تعبان", meaning: "العمل صعب", pronunciation: "el-shoghl taban" },
        { arabic: "عايز أتكلم معاك", meaning: "أريد التحدث معك", pronunciation: "aayiz atkallim maak" },
        { arabic: "الاجتماع امتى؟", meaning: "متى الاجتماع؟", pronunciation: "el-igtimaa emta?" },
      ],
      saudi: [
        { arabic: "الشغل صعب", meaning: "العمل صعب", pronunciation: "el-shoghl sa3b" },
        { arabic: "أبي أكلمك", meaning: "أريد التحدث معك", pronunciation: "abi akallimak" },
        { arabic: "الاجتماع متى؟", meaning: "متى الاجتماع؟", pronunciation: "el-ijtima' mata?" },
      ],
      levantine: [
        { arabic: "الشغل صعب", meaning: "العمل صعب", pronunciation: "el-shoghl sa3b" },
        { arabic: "بدي حكيك", meaning: "أريد التحدث معك", pronunciation: "biddi hkiik" },
        { arabic: "الاجتماع إيمتى؟", meaning: "متى الاجتماع؟", pronunciation: "el-ijtima emta?" },
      ],
    }
  },
];

export const dictionaryWords = [
  { word: "زين", dialect: "خليجي/سعودي", meaning: "جيد، حسن", example: "الأكل زين", category: "صفات" },
  { word: "بزاف", dialect: "مغربي", meaning: "كثير جداً", example: "عندي شغل بزاف", category: "كميات" },
  { word: "وايد", dialect: "خليجي", meaning: "كثير جداً", example: "شكراً وايد", category: "كميات" },
  { word: "أوي", dialect: "مصري", meaning: "جداً", example: "كويس أوي", category: "كميات" },
  { word: "كلش", dialect: "عراقي", meaning: "جداً، كثيراً", example: "زين كلش", category: "كميات" },
  { word: "هيك", dialect: "شامي", meaning: "هكذا، بهذه الطريقة", example: "عمل هيك", category: "أفعال" },
  { word: "دابا", dialect: "مغربي", meaning: "الآن، في الحال", example: "جي دابا", category: "زمن" },
  { word: "هلق", dialect: "شامي", meaning: "الآن", example: "رايح هلق", category: "زمن" },
  { word: "دلوقتي", dialect: "مصري", meaning: "الآن", example: "تعالى دلوقتي", category: "زمن" },
  { word: "واخا", dialect: "مغربي", meaning: "حسناً، موافق", example: "واخا هنا", category: "موافقة" },
  { word: "تمام", dialect: "مصري/عام", meaning: "حسناً، موافق", example: "تمام يا صديقي", category: "موافقة" },
  { word: "منيح", dialect: "شامي", meaning: "جيد، بخير", example: "أنا منيح", category: "صفات" },
  { word: "مزيان", dialect: "مغربي", meaning: "جيد، حسن", example: "هاد مزيان", category: "صفات" },
  { word: "جامد", dialect: "مصري", meaning: "رائع، ممتاز", example: "أنت جامد", category: "صفات" },
  { word: "خوش", dialect: "خليجي/عراقي", meaning: "جيد، حسن", example: "خوش كلام", category: "صفات" },
  { word: "يلا", dialect: "شامي/عام", meaning: "هيا، تعال", example: "يلا نروح", category: "أفعال" },
  { word: "هلا", dialect: "خليجي/سعودي", meaning: "أهلاً، مرحباً", example: "هلا والله", category: "تحيات" },
  { word: "إزيك", dialect: "مصري", meaning: "كيف حالك؟", example: "إزيك يا صاحبي؟", category: "تحيات" },
  { word: "لباس", dialect: "مغربي", meaning: "بخير، ليس هناك مشكلة", example: "لباس عليك", category: "تحيات" },
  { word: "شلون", dialect: "خليجي/عراقي", meaning: "كيف", example: "شلونك؟", category: "تحيات" },
];
