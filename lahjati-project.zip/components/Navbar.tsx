'use client';

import { useState } from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { MessageSquare, BookOpen, BookMarked, User, Menu, X } from 'lucide-react';

const navItems = [
  { href: '/', label: 'الرئيسية', icon: null },
  { href: '/chat', label: 'المحادثة', icon: MessageSquare },
  { href: '/lessons', label: 'الدروس', icon: BookOpen },
  { href: '/dictionary', label: 'القاموس', icon: BookMarked },
  { href: '/profile', label: 'ملفي', icon: User },
];

export default function Navbar() {
  const pathname = usePathname();
  const [mobileOpen, setMobileOpen] = useState(false);

  return (
    <header className="fixed w-full z-50 top-0">
      <div className="glass border-b border-white/5 mx-0">
        <div className="max-w-7xl mx-auto px-6 py-4 flex justify-between items-center">
          {/* Logo */}
          <Link href="/" className="flex items-center gap-3 group">
            <div className="w-10 h-10 bg-gradient-to-br from-cyan-400 to-blue-600 rounded-2xl flex items-center justify-center text-xl shadow-lg shadow-cyan-500/20 group-hover:scale-110 transition">
              🗣️
            </div>
            <span className="text-2xl font-bold tracking-tight">لهجتي</span>
          </Link>

          {/* Desktop Nav */}
          <nav className="hidden md:flex items-center gap-8">
            {navItems.map(({ href, label }) => (
              <Link
                key={href}
                href={href}
                className={`nav-link text-base font-medium ${pathname === href ? 'active text-cyan-400' : 'text-zinc-400 hover:text-white'}`}
              >
                {label}
              </Link>
            ))}
          </nav>

          {/* CTA */}
          <div className="hidden md:flex items-center gap-3">
            <Link href="/chat" className="btn-primary px-6 py-2.5 text-sm">
              ابدأ المحادثة ✨
            </Link>
          </div>

          {/* Mobile menu toggle */}
          <button className="md:hidden p-2 text-zinc-400 hover:text-white" onClick={() => setMobileOpen(!mobileOpen)}>
            {mobileOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>

        {/* Mobile Nav */}
        {mobileOpen && (
          <div className="md:hidden border-t border-white/5 bg-zinc-950/95 backdrop-blur-xl">
            {navItems.map(({ href, label, icon: Icon }) => (
              <Link
                key={href}
                href={href}
                onClick={() => setMobileOpen(false)}
                className={`flex items-center gap-3 px-6 py-4 text-base font-medium transition ${pathname === href ? 'text-cyan-400 bg-cyan-500/5' : 'text-zinc-400 hover:text-white hover:bg-white/5'}`}
              >
                {Icon && <Icon size={18} />}
                {label}
              </Link>
            ))}
          </div>
        )}
      </div>
    </header>
  );
}
