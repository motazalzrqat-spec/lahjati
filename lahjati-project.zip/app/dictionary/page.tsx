'use client';

import { useState, useMemo } from 'react';
import { Search, Volume2, Filter } from 'lucide-react';
import { dictionaryWords, dialects } from '@/lib/data';

const categories = ['الكل', 'تحيات', 'صفات', 'كميات', 'زمن', 'موافقة', 'أفعال'];

export default function DictionaryPage() {
  const [search, setSearch] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('الكل');
  const [selectedDialect, setSelectedDialect] = useState('الكل');
  const [hoveredWord, setHoveredWord] = useState<string | null>(null);

  const allDialectNames = ['الكل', ...dialects.map(d => d.name), 'عراقي', 'مصري/عام'];
  const uniqueDialects = ['الكل', ...Array.from(new Set(dictionaryWords.map(w => w.dialect)))];

  const filtered = useMemo(() => {
    return dictionaryWords.filter(word => {
      const matchSearch = !search || 
        word.word.includes(search) || 
        word.meaning.includes(search) ||
        word.example.includes(search);
      const matchCategory = selectedCategory === 'الكل' || word.category === selectedCategory;
      const matchDialect = selectedDialect === 'الكل' || word.dialect.includes(selectedDialect);
      return matchSearch && matchCategory && matchDialect;
    });
  }, [search, selectedCategory, selectedDialect]);

  const speak = (text: string) => {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.lang = 'ar-SA';
      utterance.rate = 0.8;
      window.speechSynthesis.speak(utterance);
    }
  };

  const dialectColors: Record<string, string> = {
    'مصري': 'bg-blue-500/10 text-blue-400 border-blue-500/20',
    'سعودي': 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20',
    'خليجي': 'bg-amber-500/10 text-amber-400 border-amber-500/20',
    'شامي': 'bg-red-500/10 text-red-400 border-red-500/20',
    'مغربي': 'bg-indigo-500/10 text-indigo-400 border-indigo-500/20',
    'عراقي': 'bg-teal-500/10 text-teal-400 border-teal-500/20',
  };

  const getDialectColor = (dialect: string) => {
    for (const [key, val] of Object.entries(dialectColors)) {
      if (dialect.includes(key)) return val;
    }
    return 'bg-zinc-500/10 text-zinc-400 border-zinc-500/20';
  };

  return (
    <div className="min-h-screen pt-24 pb-16 px-6">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="text-center mb-10">
          <h1 className="text-5xl font-black mb-4">قاموس اللهجات</h1>
          <p className="text-zinc-400 text-xl">اكتشف الكلمات وتعلم الفروق بين اللهجات</p>
        </div>

        {/* Search & Filters */}
        <div className="glass rounded-2xl p-5 mb-8 space-y-4">
          {/* Search */}
          <div className="relative">
            <Search size={18} className="absolute right-4 top-1/2 -translate-y-1/2 text-zinc-500" />
            <input
              type="text"
              value={search}
              onChange={e => setSearch(e.target.value)}
              placeholder="ابحث عن كلمة أو معنى..."
              className="w-full bg-zinc-900 rounded-xl py-3.5 pr-12 pl-5 focus:outline-none focus:ring-2 focus:ring-cyan-500/50"
            />
          </div>

          {/* Category Filter */}
          <div>
            <div className="flex items-center gap-2 mb-2 text-sm text-zinc-500">
              <Filter size={14} />
              التصنيف
            </div>
            <div className="flex flex-wrap gap-2">
              {categories.map(cat => (
                <button
                  key={cat}
                  onClick={() => setSelectedCategory(cat)}
                  className={`px-4 py-1.5 rounded-full text-sm font-medium transition ${
                    selectedCategory === cat
                      ? 'bg-cyan-500 text-white'
                      : 'bg-zinc-800 text-zinc-400 hover:text-white hover:bg-zinc-700'
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>
          </div>

          {/* Dialect Filter */}
          <div>
            <div className="flex items-center gap-2 mb-2 text-sm text-zinc-500">
              🗺️ اللهجة
            </div>
            <div className="flex flex-wrap gap-2">
              {uniqueDialects.map(d => (
                <button
                  key={d}
                  onClick={() => setSelectedDialect(d)}
                  className={`px-4 py-1.5 rounded-full text-sm font-medium transition ${
                    selectedDialect === d
                      ? 'bg-cyan-500 text-white'
                      : 'bg-zinc-800 text-zinc-400 hover:text-white hover:bg-zinc-700'
                  }`}
                >
                  {d}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Results count */}
        <div className="flex items-center justify-between mb-5">
          <p className="text-zinc-500 text-sm">{filtered.length} نتيجة</p>
        </div>

        {/* Words Grid */}
        {filtered.length > 0 ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
            {filtered.map((word, i) => (
              <div
                key={i}
                onMouseEnter={() => setHoveredWord(word.word)}
                onMouseLeave={() => setHoveredWord(null)}
                className={`glass rounded-2xl p-5 transition group cursor-default ${
                  hoveredWord === word.word ? 'border-white/15 shadow-lg' : ''
                }`}
              >
                <div className="flex items-start justify-between mb-3">
                  <button
                    onClick={() => speak(word.word)}
                    className="p-2 bg-zinc-800 hover:bg-cyan-500/20 hover:text-cyan-400 rounded-xl transition opacity-0 group-hover:opacity-100"
                  >
                    <Volume2 size={14} />
                  </button>
                  <div className="text-right">
                    <div className="text-3xl font-black mb-1">{word.word}</div>
                    <span className={`text-xs px-2.5 py-1 rounded-full border ${getDialectColor(word.dialect)}`}>
                      {word.dialect}
                    </span>
                  </div>
                </div>

                <div className="border-t border-zinc-800 pt-3 space-y-2">
                  <div>
                    <p className="text-xs text-zinc-500 mb-0.5">المعنى</p>
                    <p className="font-medium">{word.meaning}</p>
                  </div>
                  <div>
                    <p className="text-xs text-zinc-500 mb-0.5">مثال</p>
                    <p className="text-zinc-400 text-sm italic">"{word.example}"</p>
                  </div>
                  <div className="pt-1">
                    <span className="text-xs bg-zinc-800 text-zinc-500 px-2.5 py-1 rounded-full">
                      {word.category}
                    </span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center py-20">
            <div className="text-6xl mb-4">🔍</div>
            <p className="text-zinc-400 text-xl">لا توجد نتائج للبحث</p>
            <button onClick={() => { setSearch(''); setSelectedCategory('الكل'); setSelectedDialect('الكل'); }} className="mt-4 text-cyan-400 hover:underline text-sm">
              مسح الفلاتر
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
