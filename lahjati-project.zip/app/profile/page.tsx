'use client';

import { useState } from 'react';
import Link from 'next/link';
import { Edit3, Star, Zap, BookOpen, MessageSquare, Award, TrendingUp } from 'lucide-react';
import { dialects } from '@/lib/data';

const achievements = [
  { id: 1, icon: "🎯", title: "أول محادثة", desc: "بدأت رحلتك مع لهجتي", xp: 50, earned: true },
  { id: 2, icon: "📚", title: "متعلم نشط", desc: "أكملت ٣ دروس", xp: 150, earned: true },
  { id: 3, icon: "🔥", title: "سلسلة ٧ أيام", desc: "تعلمت ٧ أيام متتالية", xp: 200, earned: false },
  { id: 4, icon: "🌍", title: "مستكشف اللهجات", desc: "جربت ٣ لهجات مختلفة", xp: 300, earned: false },
  { id: 5, icon: "💬", title: "محادث متقدم", desc: "أجريت ٥٠ رسالة", xp: 500, earned: false },
  { id: 6, icon: "⭐", title: "نجم القاموس", desc: "بحثت عن ٢٠ كلمة", xp: 250, earned: false },
];

const weekActivity = [
  { day: "الأحد", messages: 12, lessons: 1 },
  { day: "الاثنين", messages: 8, lessons: 0 },
  { day: "الثلاثاء", messages: 20, lessons: 2 },
  { day: "الأربعاء", messages: 5, lessons: 1 },
  { day: "الخميس", messages: 15, lessons: 0 },
  { day: "الجمعة", messages: 3, lessons: 0 },
  { day: "السبت", messages: 0, lessons: 0 },
];

export default function ProfilePage() {
  const [activeTab, setActiveTab] = useState<'stats' | 'achievements' | 'dialects'>('stats');
  const [editingName, setEditingName] = useState(false);
  const [name, setName] = useState('مستخدم لهجتي');

  const totalXP = 350;
  const level = Math.floor(totalXP / 200) + 1;
  const xpToNext = 200 - (totalXP % 200);
  const xpProgress = ((totalXP % 200) / 200) * 100;

  return (
    <div className="min-h-screen pt-24 pb-16 px-6">
      <div className="max-w-5xl mx-auto">
        {/* Profile Card */}
        <div className="glass rounded-3xl p-8 mb-8 relative overflow-hidden">
          {/* Background decoration */}
          <div className="absolute top-0 left-0 right-0 h-24 bg-gradient-to-br from-cyan-500/10 to-blue-600/10" />

          <div className="relative flex flex-col sm:flex-row items-start sm:items-center gap-6">
            {/* Avatar */}
            <div className="w-24 h-24 rounded-3xl bg-gradient-to-br from-cyan-400 to-blue-600 flex items-center justify-center text-5xl shadow-xl shadow-cyan-500/20">
              🧑‍🎓
            </div>

            {/* Info */}
            <div className="flex-1">
              <div className="flex items-center gap-3 mb-1">
                {editingName ? (
                  <input
                    value={name}
                    onChange={e => setName(e.target.value)}
                    onBlur={() => setEditingName(false)}
                    onKeyDown={e => e.key === 'Enter' && setEditingName(false)}
                    className="bg-zinc-800 rounded-xl px-3 py-1.5 text-xl font-bold focus:outline-none focus:ring-2 focus:ring-cyan-500/50 w-56"
                    autoFocus
                  />
                ) : (
                  <>
                    <h2 className="text-3xl font-black">{name}</h2>
                    <button onClick={() => setEditingName(true)} className="p-1.5 text-zinc-500 hover:text-white transition">
                      <Edit3 size={16} />
                    </button>
                  </>
                )}
              </div>
              <p className="text-zinc-400 mb-4">متعلم لهجات عربية 🌟</p>

              {/* Level bar */}
              <div className="max-w-sm">
                <div className="flex justify-between text-sm mb-1.5">
                  <span className="text-zinc-400 flex items-center gap-1">
                    <Zap size={13} className="text-amber-400" />
                    المستوى {level}
                  </span>
                  <span className="text-zinc-500">{xpToNext} XP للمستوى التالي</span>
                </div>
                <div className="h-2 bg-zinc-800 rounded-full overflow-hidden">
                  <div className="progress-bar h-full rounded-full" style={{ width: `${xpProgress}%` }} />
                </div>
              </div>
            </div>

            {/* XP Badge */}
            <div className="text-center">
              <div className="w-20 h-20 rounded-3xl bg-amber-500/10 border border-amber-500/20 flex flex-col items-center justify-center">
                <span className="text-2xl font-black text-amber-400">{totalXP}</span>
                <span className="text-xs text-zinc-500">XP</span>
              </div>
            </div>
          </div>
        </div>

        {/* Quick Stats */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mb-8">
          {[
            { icon: MessageSquare, label: "رسائل", value: "٦٣", color: "text-cyan-400" },
            { icon: BookOpen, label: "دروس", value: "٣", color: "text-blue-400" },
            { icon: Star, label: "نقاط XP", value: "٣٥٠", color: "text-amber-400" },
            { icon: TrendingUp, label: "أيام متتالية", value: "٤", color: "text-emerald-400" },
          ].map(({ icon: Icon, label, value, color }, i) => (
            <div key={i} className="glass rounded-2xl p-5 text-center">
              <Icon size={22} className={`${color} mx-auto mb-2`} />
              <div className="text-2xl font-black mb-0.5">{value}</div>
              <div className="text-xs text-zinc-500">{label}</div>
            </div>
          ))}
        </div>

        {/* Tabs */}
        <div className="flex gap-2 mb-6">
          {[
            { id: 'stats', label: 'النشاط' },
            { id: 'achievements', label: 'الإنجازات' },
            { id: 'dialects', label: 'اللهجات' },
          ].map(({ id, label }) => (
            <button
              key={id}
              onClick={() => setActiveTab(id as typeof activeTab)}
              className={`px-6 py-2.5 rounded-xl font-medium text-sm transition ${
                activeTab === id
                  ? 'bg-cyan-500 text-white'
                  : 'glass text-zinc-400 hover:text-white'
              }`}
            >
              {label}
            </button>
          ))}
        </div>

        {/* Tab Content */}
        {activeTab === 'stats' && (
          <div className="glass rounded-2xl p-6">
            <h3 className="font-bold text-xl mb-6 flex items-center gap-2">
              <TrendingUp size={20} className="text-cyan-400" />
              نشاط الأسبوع
            </h3>
            <div className="flex items-end gap-3 h-40">
              {weekActivity.map((day, i) => {
                const maxMessages = Math.max(...weekActivity.map(d => d.messages));
                const height = maxMessages > 0 ? (day.messages / maxMessages) * 100 : 0;
                const isToday = i === new Date().getDay();

                return (
                  <div key={i} className="flex-1 flex flex-col items-center gap-2">
                    <div className="w-full relative flex flex-col justify-end" style={{ height: '120px' }}>
                      <div
                        className={`w-full rounded-t-xl transition-all ${
                          isToday
                            ? 'bg-gradient-to-t from-cyan-600 to-cyan-400'
                            : day.messages > 0
                              ? 'bg-zinc-700 hover:bg-zinc-600'
                              : 'bg-zinc-900'
                        }`}
                        style={{ height: `${Math.max(height, day.messages > 0 ? 10 : 4)}%` }}
                      />
                    </div>
                    <span className="text-xs text-zinc-500">{day.day.slice(0, 2)}</span>
                    {day.lessons > 0 && (
                      <div className="w-1.5 h-1.5 rounded-full bg-amber-400" title={`${day.lessons} دروس`} />
                    )}
                  </div>
                );
              })}
            </div>
            <p className="text-center text-xs text-zinc-500 mt-4">الأعمدة = الرسائل · النقاط الصفراء = دروس مكتملة</p>
          </div>
        )}

        {activeTab === 'achievements' && (
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {achievements.map(a => (
              <div
                key={a.id}
                className={`glass rounded-2xl p-5 flex items-center gap-4 transition ${
                  a.earned ? 'border-amber-500/20' : 'opacity-50'
                }`}
              >
                <div className={`w-14 h-14 rounded-2xl flex items-center justify-center text-2xl flex-shrink-0 ${
                  a.earned ? 'bg-amber-500/10' : 'bg-zinc-800'
                }`}>
                  {a.earned ? a.icon : '🔒'}
                </div>
                <div className="flex-1">
                  <div className="font-bold mb-0.5">{a.title}</div>
                  <div className="text-zinc-400 text-sm">{a.desc}</div>
                  <div className="text-amber-400 text-xs mt-1">+{a.xp} XP</div>
                </div>
                {a.earned && <Award size={16} className="text-amber-400 flex-shrink-0" />}
              </div>
            ))}
          </div>
        )}

        {activeTab === 'dialects' && (
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {dialects.map(dialect => {
              const progress = Math.floor(Math.random() * 80) + 10; // Demo data
              return (
                <div key={dialect.id} className="glass rounded-2xl p-5">
                  <div className="flex items-center gap-3 mb-4">
                    <span className="text-3xl">{dialect.flag}</span>
                    <div>
                      <div className="font-bold">{dialect.name}</div>
                      <div className="text-zinc-500 text-sm">{dialect.region}</div>
                    </div>
                    <span className="text-2xl font-bold mr-auto text-cyan-400">{progress}%</span>
                  </div>
                  <div className="h-1.5 bg-zinc-800 rounded-full overflow-hidden">
                    <div
                      className={`h-full bg-gradient-to-r ${dialect.color} rounded-full`}
                      style={{ width: `${progress}%` }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {/* Start Learning CTA */}
        <div className="mt-8 text-center">
          <Link href="/chat" className="btn-primary inline-flex items-center gap-2 px-8 py-3.5 rounded-2xl">
            <MessageSquare size={18} />
            ابدأ محادثة جديدة
          </Link>
        </div>
      </div>
    </div>
  );
}
