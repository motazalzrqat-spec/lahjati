'use client';

import { useState, useRef, useEffect, Suspense } from 'react';
import { useSearchParams } from 'next/navigation';
import { Send, Mic, Volume2, RotateCcw, ChevronDown } from 'lucide-react';
import { dialects } from '@/lib/data';

interface Message {
  role: 'user' | 'assistant';
  content: string;
}

function ChatContent() {
  const searchParams = useSearchParams();
  const initialDialect = dialects.find(d => d.id === searchParams.get('dialect')) || dialects[0];

  const [selectedDialect, setSelectedDialect] = useState(initialDialect);
  const [messages, setMessages] = useState<Message[]>([
    {
      role: 'assistant',
      content: `أهلاً وسهلاً! أنا مساعدك لتعلم اللهجة ${initialDialect.name} ${initialDialect.flag}\n\nيمكنك كتابة أي جملة وسأساعدك على قولها باللهجة ${initialDialect.name}، أو اسألني عن كلمات ومعاني. ابدأ الآن! 😊`
    }
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [showDialects, setShowDialects] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const switchDialect = (dialect: typeof dialects[0]) => {
    setSelectedDialect(dialect);
    setShowDialects(false);
    setMessages([{
      role: 'assistant',
      content: `تم التبديل للهجة ${dialect.name} ${dialect.flag}\n\nأهلاً! ابدأ بكتابة أي جملة وسأعلمك كيف تقولها باللهجة ${dialect.name} 🎯`
    }]);
  };

  const sendMessage = async () => {
    if (!input.trim() || isLoading) return;

    const userMessage = input.trim();
    setInput('');
    setMessages(prev => [...prev, { role: 'user', content: userMessage }]);
    setIsLoading(true);

    try {
      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          messages: [...messages, { role: 'user', content: userMessage }],
          systemPrompt: selectedDialect.systemPrompt,
          dialectName: selectedDialect.name,
        }),
      });

      const data = await response.json();

      if (data.error) {
        setMessages(prev => [...prev, {
          role: 'assistant',
          content: `⚠️ ${data.error}\n\nللتطوير: أضف ANTHROPIC_API_KEY في ملف .env.local`
        }]);
      } else {
        setMessages(prev => [...prev, { role: 'assistant', content: data.message }]);
      }
    } catch {
      setMessages(prev => [...prev, {
        role: 'assistant',
        content: '⚠️ حدث خطأ في الاتصال. تأكد من إضافة ANTHROPIC_API_KEY في .env.local'
      }]);
    } finally {
      setIsLoading(false);
    }
  };

  const speak = (text: string) => {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.lang = 'ar-SA';
      utterance.rate = 0.85;
      window.speechSynthesis.speak(utterance);
      setIsSpeaking(true);
      utterance.onend = () => setIsSpeaking(false);
    }
  };

  const clearChat = () => {
    setMessages([{
      role: 'assistant',
      content: `أهلاً من جديد! ${selectedDialect.flag} ابدأ محادثة جديدة باللهجة ${selectedDialect.name}`
    }]);
  };

  const quickPrompts = [
    "كيف أقول مرحباً؟",
    "علمني كلمات التحية",
    "كيف أطلب الطعام؟",
    "ما الفرق بينها وبين الفصحى؟",
  ];

  return (
    <div className="flex h-screen pt-20">
      {/* Sidebar */}
      <aside className="hidden lg:flex flex-col w-72 border-l border-zinc-800 bg-zinc-950 p-5 gap-4">
        <div>
          <h3 className="text-sm font-semibold text-zinc-500 uppercase tracking-wider mb-3">اللهجات المتاحة</h3>
          <div className="space-y-2">
            {dialects.map(dialect => (
              <button
                key={dialect.id}
                onClick={() => switchDialect(dialect)}
                className={`w-full flex items-center gap-3 p-3 rounded-xl text-right transition ${
                  selectedDialect.id === dialect.id
                    ? 'bg-cyan-500/10 border border-cyan-500/30 text-cyan-400'
                    : 'hover:bg-zinc-800 text-zinc-400 hover:text-white border border-transparent'
                }`}
              >
                <span className="text-2xl">{dialect.flag}</span>
                <div>
                  <div className="font-medium text-sm">{dialect.name}</div>
                  <div className="text-xs text-zinc-500">{dialect.region}</div>
                </div>
              </button>
            ))}
          </div>
        </div>

        <div className="border-t border-zinc-800 pt-4">
          <h3 className="text-sm font-semibold text-zinc-500 uppercase tracking-wider mb-3">أسئلة سريعة</h3>
          <div className="space-y-2">
            {quickPrompts.map((prompt, i) => (
              <button
                key={i}
                onClick={() => { setInput(prompt); inputRef.current?.focus(); }}
                className="w-full text-right text-sm p-2.5 rounded-xl bg-zinc-900 hover:bg-zinc-800 text-zinc-400 hover:text-white transition"
              >
                {prompt}
              </button>
            ))}
          </div>
        </div>
      </aside>

      {/* Main Chat */}
      <div className="flex-1 flex flex-col min-w-0">
        {/* Chat Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-zinc-800 bg-zinc-950">
          <div className="flex items-center gap-3">
            {/* Mobile dialect selector */}
            <div className="lg:hidden relative">
              <button
                onClick={() => setShowDialects(!showDialects)}
                className="flex items-center gap-2 bg-zinc-800 rounded-xl px-4 py-2.5 text-sm font-medium"
              >
                <span>{selectedDialect.flag}</span>
                <span>{selectedDialect.name}</span>
                <ChevronDown size={14} />
              </button>
              {showDialects && (
                <div className="absolute top-full mt-2 right-0 w-48 bg-zinc-800 rounded-2xl border border-zinc-700 shadow-xl z-50 overflow-hidden">
                  {dialects.map(d => (
                    <button
                      key={d.id}
                      onClick={() => switchDialect(d)}
                      className="w-full flex items-center gap-3 px-4 py-3 hover:bg-zinc-700 text-right text-sm transition"
                    >
                      <span>{d.flag}</span>
                      <span>{d.name}</span>
                    </button>
                  ))}
                </div>
              )}
            </div>

            <div className="hidden lg:block">
              <div className="flex items-center gap-2">
                <span className="text-2xl">{selectedDialect.flag}</span>
                <div>
                  <div className="font-semibold">اللهجة {selectedDialect.name}</div>
                  <div className="text-xs text-zinc-500">{selectedDialect.region}</div>
                </div>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <div className="w-2 h-2 bg-emerald-400 rounded-full animate-pulse" />
            <span className="text-xs text-zinc-500 hidden sm:block">Claude AI متصل</span>
            <button onClick={clearChat} className="p-2 hover:bg-zinc-800 rounded-xl text-zinc-500 hover:text-white transition">
              <RotateCcw size={16} />
            </button>
          </div>
        </div>

        {/* Messages */}
        <div className="flex-1 overflow-y-auto p-6 space-y-4 bg-gradient-to-b from-zinc-950 to-zinc-900">
          {messages.map((msg, i) => (
            <div key={i} className={`flex ${msg.role === 'user' ? 'justify-start' : 'justify-end'} message-bubble`}>
              <div className={`max-w-[80%] lg:max-w-[65%] relative group`}>
                <div className={`rounded-2xl px-5 py-4 text-base leading-relaxed whitespace-pre-wrap ${
                  msg.role === 'user'
                    ? 'bg-zinc-800 text-white rounded-tr-sm'
                    : 'bg-gradient-to-br from-cyan-600 to-blue-700 text-white rounded-tl-sm shadow-lg shadow-cyan-500/10'
                }`}>
                  {msg.content}
                </div>
                {msg.role === 'assistant' && (
                  <button
                    onClick={() => speak(msg.content)}
                    className="absolute -bottom-2 -right-2 p-1.5 bg-zinc-800 rounded-full text-zinc-400 hover:text-cyan-400 opacity-0 group-hover:opacity-100 transition"
                  >
                    <Volume2 size={12} />
                  </button>
                )}
              </div>
            </div>
          ))}

          {isLoading && (
            <div className="flex justify-end">
              <div className="bg-gradient-to-br from-cyan-600 to-blue-700 rounded-2xl rounded-tl-sm px-5 py-4">
                <div className="flex gap-1.5 items-center">
                  {[0, 1, 2].map(i => (
                    <div key={i} className="w-2 h-2 bg-white/60 rounded-full animate-bounce" style={{ animationDelay: `${i * 0.15}s` }} />
                  ))}
                </div>
              </div>
            </div>
          )}
          <div ref={messagesEndRef} />
        </div>

        {/* Input */}
        <div className="p-4 border-t border-zinc-800 bg-zinc-950">
          <div className="flex gap-3 max-w-4xl mx-auto">
            <button
              onClick={() => speak(messages[messages.length - 1]?.content || '')}
              className={`p-3.5 rounded-2xl transition flex-shrink-0 ${isSpeaking ? 'bg-red-500/20 text-red-400' : 'bg-zinc-800 text-zinc-400 hover:text-white hover:bg-zinc-700'}`}
            >
              <Volume2 size={18} />
            </button>
            <input
              ref={inputRef}
              type="text"
              value={input}
              onChange={e => setInput(e.target.value)}
              onKeyDown={e => e.key === 'Enter' && !e.shiftKey && sendMessage()}
              placeholder={`اكتب بالعربي وسأترجم للهجة ${selectedDialect.name}...`}
              className="flex-1 bg-zinc-800 rounded-2xl px-5 py-3.5 focus:outline-none focus:ring-2 focus:ring-cyan-500/50 text-base placeholder:text-zinc-500"
              disabled={isLoading}
            />
            <button
              onClick={sendMessage}
              disabled={!input.trim() || isLoading}
              className="btn-primary p-3.5 rounded-2xl flex-shrink-0 disabled:opacity-40 disabled:cursor-not-allowed disabled:transform-none"
            >
              <Send size={18} />
            </button>
          </div>
          <p className="text-center text-xs text-zinc-600 mt-2">
            مدعوم بـ Claude AI · اضغط Enter للإرسال
          </p>
        </div>
      </div>
    </div>
  );
}

export default function ChatPage() {
  return (
    <Suspense fallback={<div className="flex items-center justify-center h-screen text-zinc-400">جارٍ التحميل...</div>}>
      <ChatContent />
    </Suspense>
  );
}
