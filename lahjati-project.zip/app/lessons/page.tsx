'use client';

import { useState } from 'react';
import { BookOpen, Clock, Star, Volume2, ChevronDown, ChevronUp, CheckCircle } from 'lucide-react';
import { lessonsData, dialects } from '@/lib/data';

const levelColors: Record<string, string> = {
  'مبتدئ': 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20',
  'متوسط': 'bg-amber-500/10 text-amber-400 border-amber-500/20',
  'متقدم': 'bg-red-500/10 text-red-400 border-red-500/20',
};

export default function LessonsPage() {
  const [selectedLesson, setSelectedLesson] = useState<typeof lessonsData[0] | null>(null);
  const [selectedDialectId, setSelectedDialectId] = useState('egyptian');
  const [completedLessons, setCompletedLessons] = useState<Set<number>>(new Set());
  const [expandedPhrase, setExpandedPhrase] = useState<number | null>(null);

  const availableDialects = selectedLesson
    ? dialects.filter(d => selectedLesson.dialects.includes(d.id))
    : dialects;

  const speak = (text: string) => {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.lang = 'ar-SA';
      utterance.rate = 0.8;
      window.speechSynthesis.speak(utterance);
    }
  };

  const completeLesson = (lessonId: number) => {
    setCompletedLessons(prev => new Set([...prev, lessonId]));
  };

  const totalXP = [...completedLessons].reduce((sum, id) => {
    const lesson = lessonsData.find(l => l.id === id);
    return sum + (lesson?.xp || 0);
  }, 0);

  return (
    <div className="min-h-screen pt-24 pb-16 px-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-5xl font-black mb-4">الدروس التعليمية</h1>
          <p className="text-zinc-400 text-xl">تعلم اللهجات خطوة بخطوة مع أمثلة حقيقية</p>

          {/* Progress bar */}
          <div className="max-w-md mx-auto mt-8">
            <div className="flex justify-between text-sm text-zinc-400 mb-2">
              <span>{completedLessons.size} / {lessonsData.length} دروس مكتملة</span>
              <span className="text-amber-400">⭐ {totalXP} XP</span>
            </div>
            <div className="h-2 bg-zinc-800 rounded-full overflow-hidden">
              <div
                className="progress-bar h-full rounded-full"
                style={{ width: `${(completedLessons.size / lessonsData.length) * 100}%` }}
              />
            </div>
          </div>
        </div>

        <div className="grid lg:grid-cols-5 gap-8">
          {/* Lessons List */}
          <div className="lg:col-span-2 space-y-4">
            {lessonsData.map((lesson) => {
              const isDone = completedLessons.has(lesson.id);
              const isSelected = selectedLesson?.id === lesson.id;

              return (
                <button
                  key={lesson.id}
                  onClick={() => {
                    setSelectedLesson(lesson);
                    const firstAvailableDialect = lesson.dialects[0];
                    setSelectedDialectId(firstAvailableDialect);
                  }}
                  className={`w-full text-right glass rounded-2xl p-5 transition group hover:border-white/15 ${
                    isSelected ? 'border-cyan-500/40 bg-cyan-500/5' : ''
                  } ${isDone ? 'opacity-75' : ''}`}
                >
                  <div className="flex items-start gap-4">
                    <div className={`w-14 h-14 rounded-2xl flex items-center justify-center text-2xl flex-shrink-0 transition group-hover:scale-110 ${
                      isSelected ? 'bg-cyan-500/20' : 'bg-zinc-800'
                    }`}>
                      {isDone ? '✅' : lesson.icon}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1">
                        <h3 className="font-bold text-lg">{lesson.title}</h3>
                        {isDone && <CheckCircle size={16} className="text-emerald-400 flex-shrink-0" />}
                      </div>
                      <div className="flex flex-wrap gap-2 text-xs">
                        <span className={`px-2.5 py-1 rounded-full border ${levelColors[lesson.level]}`}>
                          {lesson.level}
                        </span>
                        <span className="flex items-center gap-1 text-zinc-500">
                          <Clock size={11} /> {lesson.duration}
                        </span>
                        <span className="flex items-center gap-1 text-amber-500">
                          <Star size={11} /> {lesson.xp} XP
                        </span>
                      </div>
                    </div>
                  </div>
                </button>
              );
            })}
          </div>

          {/* Lesson Content */}
          <div className="lg:col-span-3">
            {selectedLesson ? (
              <div className="glass rounded-3xl overflow-hidden sticky top-24">
                {/* Lesson Header */}
                <div className="bg-gradient-to-r from-cyan-600/20 to-blue-600/20 p-6 border-b border-zinc-800">
                  <div className="flex items-center gap-4 mb-4">
                    <div className="text-5xl">{selectedLesson.icon}</div>
                    <div>
                      <h2 className="text-2xl font-bold">{selectedLesson.title}</h2>
                      <div className="flex gap-2 mt-1">
                        <span className={`text-xs px-2.5 py-1 rounded-full border ${levelColors[selectedLesson.level]}`}>
                          {selectedLesson.level}
                        </span>
                        <span className="text-xs text-zinc-500 flex items-center gap-1">
                          <Clock size={11} /> {selectedLesson.duration}
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Dialect Tabs */}
                  <div className="flex gap-2 flex-wrap">
                    {availableDialects
                      .filter(d => selectedLesson.dialects.includes(d.id))
                      .map(dialect => (
                        <button
                          key={dialect.id}
                          onClick={() => setSelectedDialectId(dialect.id)}
                          className={`flex items-center gap-1.5 px-4 py-2 rounded-xl text-sm font-medium transition ${
                            selectedDialectId === dialect.id
                              ? 'bg-cyan-500 text-white'
                              : 'bg-zinc-800 text-zinc-400 hover:text-white hover:bg-zinc-700'
                          }`}
                        >
                          {dialect.flag} {dialect.name}
                        </button>
                      ))}
                  </div>
                </div>

                {/* Phrases */}
                <div className="p-6 space-y-3 max-h-[50vh] overflow-y-auto">
                  {(selectedLesson.phrases[selectedDialectId as keyof typeof selectedLesson.phrases] || []).map((phrase, i) => (
                    <div key={i} className="bg-zinc-900 rounded-2xl overflow-hidden">
                      <button
                        onClick={() => setExpandedPhrase(expandedPhrase === i ? null : i)}
                        className="w-full flex items-center justify-between p-4 text-right"
                      >
                        <div className="flex items-center gap-3">
                          <span className="w-7 h-7 bg-cyan-500/20 text-cyan-400 rounded-full flex items-center justify-center text-xs font-bold flex-shrink-0">
                            {i + 1}
                          </span>
                          <div>
                            <div className="text-xl font-bold">{phrase.arabic}</div>
                            <div className="text-zinc-400 text-sm">{phrase.meaning}</div>
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          <button
                            onClick={(e) => { e.stopPropagation(); speak(phrase.arabic); }}
                            className="p-2 bg-zinc-800 hover:bg-cyan-500/20 hover:text-cyan-400 rounded-xl transition"
                          >
                            <Volume2 size={14} />
                          </button>
                          {expandedPhrase === i ? <ChevronUp size={16} className="text-zinc-400" /> : <ChevronDown size={16} className="text-zinc-400" />}
                        </div>
                      </button>

                      {expandedPhrase === i && (
                        <div className="px-4 pb-4 border-t border-zinc-800 pt-3">
                          <div className="bg-zinc-800 rounded-xl p-3">
                            <p className="text-xs text-zinc-500 mb-1">النطق بالحروف اللاتينية:</p>
                            <p className="text-zinc-300 font-mono text-sm">{phrase.pronunciation}</p>
                          </div>
                        </div>
                      )}
                    </div>
                  ))}
                </div>

                {/* Complete Button */}
                <div className="p-6 border-t border-zinc-800">
                  {completedLessons.has(selectedLesson.id) ? (
                    <div className="flex items-center justify-center gap-2 py-3 text-emerald-400">
                      <CheckCircle size={20} />
                      <span className="font-semibold">تم إكمال الدرس! +{selectedLesson.xp} XP</span>
                    </div>
                  ) : (
                    <button
                      onClick={() => completeLesson(selectedLesson.id)}
                      className="btn-primary w-full py-3.5 rounded-2xl font-semibold text-center"
                    >
                      إكمال الدرس وكسب {selectedLesson.xp} XP ⭐
                    </button>
                  )}
                </div>
              </div>
            ) : (
              <div className="glass rounded-3xl p-16 text-center">
                <div className="text-7xl mb-6 animate-float">📚</div>
                <h3 className="text-2xl font-bold mb-3">اختر درساً للبدء</h3>
                <p className="text-zinc-400">اختر أي درس من القائمة لعرض المحتوى والعبارات</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
