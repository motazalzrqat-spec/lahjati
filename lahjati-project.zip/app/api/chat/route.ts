import { NextRequest, NextResponse } from 'next/server';
import Anthropic from '@anthropic-ai/sdk';

const client = new Anthropic({
  apiKey: process.env.ANTHROPIC_API_KEY,
});

export async function POST(req: NextRequest) {
  try {
    const { messages, systemPrompt, dialectName } = await req.json();

    if (!process.env.ANTHROPIC_API_KEY) {
      return NextResponse.json(
        { error: 'ANTHROPIC_API_KEY غير موجود. أضف المفتاح في .env.local' },
        { status: 500 }
      );
    }

    const system = systemPrompt || `أنت مساعد متخصص في تعليم اللهجات العربية.
اللهجة الحالية: ${dialectName || 'عربي عام'}.
ساعد المستخدم على تعلم اللهجة وصحح أخطاءه بطريقة لطيفة ومشجعة.
قدم أمثلة عملية وقارن بين اللهجة والفصحى عند الحاجة.
استجب دائماً بالعربية.`;

    const response = await client.messages.create({
      model: 'claude-opus-4-5',
      max_tokens: 1024,
      system,
      messages: messages.map((m: { role: string; content: string }) => ({
        role: m.role as 'user' | 'assistant',
        content: m.content,
      })),
    });

    const content = response.content[0];
    if (content.type !== 'text') {
      return NextResponse.json({ error: 'خطأ في الاستجابة' }, { status: 500 });
    }

    return NextResponse.json({ message: content.text });
  } catch (error) {
    console.error('Claude API Error:', error);
    return NextResponse.json(
      { error: 'حدث خطأ في الاتصال بـ Claude AI' },
      { status: 500 }
    );
  }
}
