'use client';

import Link from 'next/link';
import { Mic, BookOpen, BookMarked, Star, Users, Zap, ArrowLeft } from 'lucide-react';
import { dialects } from '@/lib/data';

const features = [
  { icon: Mic, title: "محادثات ذكية", desc: "تحدث مع AI يفهم لهجتك ويصحح أخطاءك في الوقت الفعلي", color: "text-cyan-400" },
  { icon: BookOpen, title: "دروس تفاعلية", desc: "٦ دروس متدرجة من المبتدئ للمتقدم مع تمارين عملية", color: "text-blue-400" },
  { icon: BookMarked, title: "قاموس اللهجات", desc: "٢٠٠+ كلمة موثقة مع النطق والأمثلة من ٦ لهجات", color: "text-purple-400" },
  { icon: Star, title: "نظام النقاط", desc: "اكسب XP وتتبع تقدمك مع شارات الإنجاز", color: "text-amber-400" },
];

const stats = [
  { number: "٦", label: "لهجات عربية" },
  { number: "٢٠٠+", label: "كلمة في القاموس" },
  { number: "٣٠+", label: "جملة تعليمية" },
  { number: "١٠٠٪", label: "مدعوم بـ Claude AI" },
];

export default function Home() {
  return (
    <div className="min-h-screen">
      {/* Hero */}
      <section className="pt-36 pb-24 px-6 text-center relative overflow-hidden">
        {/* Background glow */}
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-cyan-500/5 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute top-1/4 left-1/4 w-[400px] h-[400px] bg-blue-500/5 rounded-full blur-3xl pointer-events-none" />

        <div className="relative max-w-4xl mx-auto">
          <div className="inline-flex items-center gap-2 bg-cyan-500/10 border border-cyan-500/20 rounded-full px-5 py-2 text-sm text-cyan-400 mb-8">
            <Zap size={14} />
            مدعوم بـ Claude AI من Anthropic
          </div>

          <h1 className="text-6xl md:text-7xl font-black leading-tight mb-6">
            تعلم اللهجة اللي تحبها<br />
            <span className="gradient-text">بالذكاء الاصطناعي</span>
          </h1>

          <p className="text-xl text-zinc-400 mb-10 max-w-2xl mx-auto leading-relaxed">
            محادثات حقيقية مع AI، دروس يومية، وقاموس شامل لـ ٦ لهجات عربية أصيلة
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/chat" className="btn-primary inline-flex items-center gap-2 px-10 py-4 text-lg rounded-2xl">
              <Mic size={20} />
              ابدأ المحادثة الآن
            </Link>
            <Link href="/lessons" className="inline-flex items-center gap-2 px-10 py-4 text-lg rounded-2xl border border-zinc-700 hover:border-zinc-500 transition text-zinc-300">
              <BookOpen size={20} />
              استكشف الدروس
            </Link>
          </div>
        </div>
      </section>

      {/* Stats */}
      <section className="max-w-5xl mx-auto px-6 pb-20">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {stats.map((stat, i) => (
            <div key={i} className="glass rounded-2xl p-6 text-center">
              <div className="text-4xl font-black gradient-text mb-1">{stat.number}</div>
              <div className="text-zinc-400 text-sm">{stat.label}</div>
            </div>
          ))}
        </div>
      </section>

      {/* Dialects */}
      <section className="max-w-7xl mx-auto px-6 pb-24">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold mb-3">اختر لهجتك</h2>
          <p className="text-zinc-400 text-lg">كل لهجة عالم خاص — ابدأ المحادثة في ثوانٍ</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {dialects.map((dialect) => (
            <Link
              key={dialect.id}
              href={`/chat?dialect=${dialect.id}`}
              className="dialect-card glass rounded-3xl p-8 block group"
            >
              <div className="text-6xl mb-5 transition-transform group-hover:scale-110 inline-block">{dialect.flag}</div>
              <div className="flex items-start justify-between mb-2">
                <h3 className="text-3xl font-bold">{dialect.name}</h3>
                <span className="text-xs bg-zinc-800 text-zinc-400 px-3 py-1 rounded-full mt-1">{dialect.speakers}</span>
              </div>
              <p className="text-zinc-400 mb-1">{dialect.description}</p>
              <p className="text-zinc-500 text-sm italic mb-5">"{dialect.example}"</p>
              <div className={`h-1 w-20 bg-gradient-to-r ${dialect.color} rounded-full`} />
            </Link>
          ))}
        </div>
      </section>

      {/* Features */}
      <section id="features" className="max-w-6xl mx-auto px-6 pb-24">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold mb-3">كل ما تحتاجه لتعلم اللهجات</h2>
          <p className="text-zinc-400 text-lg">منصة متكاملة مدعومة بأحدث تقنيات الذكاء الاصطناعي</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {features.map(({ icon: Icon, title, desc, color }, i) => (
            <div key={i} className="glass rounded-2xl p-8 flex gap-5 group hover:border-white/15 transition">
              <div className={`w-12 h-12 rounded-2xl bg-zinc-800 flex items-center justify-center flex-shrink-0 ${color} group-hover:scale-110 transition`}>
                <Icon size={22} />
              </div>
              <div>
                <h3 className="text-xl font-semibold mb-2">{title}</h3>
                <p className="text-zinc-400 leading-relaxed">{desc}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* CTA */}
      <section className="max-w-4xl mx-auto px-6 pb-32">
        <div className="relative glass rounded-3xl p-12 text-center overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-br from-cyan-500/10 to-blue-600/10" />
          <div className="relative">
            <div className="text-6xl mb-6 animate-float">🎯</div>
            <h2 className="text-4xl font-bold mb-4">مستعد تبدأ رحلتك؟</h2>
            <p className="text-zinc-400 mb-8 text-lg">ابدأ محادثتك الأولى الآن — مجاناً، بدون تسجيل</p>
            <Link href="/chat" className="btn-primary inline-flex items-center gap-2 px-10 py-4 text-lg rounded-2xl">
              ابدأ الآن
              <ArrowLeft size={18} />
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}
