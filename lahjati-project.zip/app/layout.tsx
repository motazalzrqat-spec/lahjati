import type { Metadata } from "next";
import "./globals.css";
import Navbar from "@/components/Navbar";

export const metadata: Metadata = {
  title: "لهجتي | Lahjati - تعلم اللهجات العربية بالذكاء الاصطناعي",
  description: "محادثات صوتية مع AI، دروس، وقاموس اللهجات العربية",
  icons: { icon: "/favicon.ico" },
  openGraph: {
    title: "لهجتي - تعلم اللهجات العربية",
    description: "محادثات حقيقية بالذكاء الاصطناعي لتعلم اللهجات العربية",
    locale: "ar_SA",
  }
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="ar" dir="rtl">
      <body className="bg-zinc-950 text-white antialiased min-h-screen">
        <Navbar />
        <main>{children}</main>
      </body>
    </html>
  );
}
